package whatever.proyectocajero;
// este sera el main por lo tanto se manejara unicamente las funciones desde aca para correr el codigo.

import javax.swing.JOptionPane;

public class ProyectoCajero {
    public static void main(String[] args) {   
    }
}
